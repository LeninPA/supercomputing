#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#define MASTER 0

int main( int argc, char** argv )
{
	int world_size;
	int world_rank;

	MPI_Init(NULL,NULL); /* MPI_Init(&argc,&argv) */
	MPI_Comm_size(MPI_COMM_WORLD, &world_size);
	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
	if ( world_size < 2 ) 
	{
		fprintf(stderr, "El programa debe de ser ejecutado con dos o mas procesos (%i)\n", world_size);
		MPI_Abort(MPI_COMM_WORLD, 1);
	}

	if ( world_rank == MASTER )
		fprintf(stdout, "[MASTER] Identificador en la ejecucio��n %i\n", world_rank);
	else fprintf(stderr, "[WORKER] Tamaño del comunicador MPI_COMM_WORLD %i\n", world_size);

	fprintf(stdout, "Identificador en la ejecución %i\n", world_rank);
	fprintf(stderr, "Tamaño del comunicador MPI_COMM_WORLD %i\n", world_size);

	MPI_Finalize();
	return 0;
}
