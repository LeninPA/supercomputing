#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MASTER 0

int main( int argc, char** argv )
{
	int world_size;
	int world_rank;
	int number;

	MPI_Init(NULL,NULL); /* MPI_Init(&argc,&argv) */
	MPI_Comm_size(MPI_COMM_WORLD, &world_size);
	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
	srand(time(NULL));
	if ( world_size < 2 ) 
	{
		fprintf(stderr, "El programa debe de ser ejecutado con dos o mas procesos (%i)\n", world_size);
		MPI_Abort(MPI_COMM_WORLD, 1);
	}

	if ( world_rank == MASTER )
	{
		fprintf(stdout, "[MASTER] Identificador en la ejecucio��n %i\n", world_rank);
		number = -1;
		while ( number != 0)
		{
			printf("[MASTER] Write a number: ");
			scanf("%d", &number);
			MPI_Send(&number, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
			printf("[MASTER] Process 0 sent number %d to process 0\n", number);
			MPI_Recv(&number, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			printf("[MASTER] Process 0 received number %d from process 0\n", number);
		}
	}	
	else if ( world_rank == 1 )
	{
		number = -1;
		while ( number != 0)
		{
		// fprintf(stderr, "[WORKER] Tamaño del comunicador MPI_COMM_WORLD %i\n", world_size);
		MPI_Recv(&number, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		printf("[WORKER] Process 1 received number %d from process 0\n", number);
		number = 10 * number;
		printf("[WORKER] Process 1 sent number %d to process 0\n", number);
		MPI_Send(&number, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
		}
	}
	fprintf(stdout, "Identificador en la ejecución %i\n", world_rank);
	fprintf(stderr, "Tamaño del comunicador MPI_COMM_WORLD %i\n", world_size);

	MPI_Finalize();
	return 0;
}
