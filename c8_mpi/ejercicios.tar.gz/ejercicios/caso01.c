#include <string.h>
#include <stdio.h>
#include "mpi.h"

#define BUFFERMAX 20

int main ( int argc , char **argv ) {
 char message [ BUFFERMAX ]; /* message to send */
 int id ; /* rank of executing process */
 MPI_Status status ; /* status to pass to MPI_Recv */
 int tag = 10; /* a random tag value */
 int count = 0; /* size message */


 MPI_Init( &argc , &argv ) ;
 MPI_Comm_rank( MPI_COMM_WORLD , &id ) ;
 if ( id == 0) { /* process 0 sends */
 strcpy( message , "Hello , world" ) ;
 MPI_Send( message , strlen( message ) +1 , MPI_CHAR , 
    1, 
    tag, 
    MPI_COMM_WORLD );
 }
 else if ( id == 1) { /* process 1 receives from any process any tag */
 MPI_Recv( message , BUFFERMAX , MPI_CHAR ,
    MPI_ANY_SOURCE,
    MPI_ANY_TAG,
    MPI_COMM_WORLD, 
    &status ) ;

 printf( " \"% s ,\" from process % d " , message , id ) ;
 printf( " ( Sender is process % d ; tag = % d ) \n" , 
    status.MPI_SOURCE , 
    status.MPI_TAG ) ;

  MPI_Get_count(&status, MPI_CHAR, &count);
  printf("Task %d: Received %d char(s) from task %d with tag %d \n",
         id, count, status.MPI_SOURCE, status.MPI_TAG);


 }
 MPI_Finalize() ;
 return 0;
}

