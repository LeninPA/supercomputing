# Lista de programas
1. Dados dos números devuelve el más grande
2. Calculadora para enteros con suma, resta, multiplicación y división con protección para divisón contra cero
3. Obtiene los primeros n+1 números de la sucesión de fibonacci
4. Obtiene el máximo común divisor de dos números usando el algoritmo de euclides sin división
