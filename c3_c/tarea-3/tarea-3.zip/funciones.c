int suma ( int a, int b ) {
		return a + b;
}
int maximo ( int a, int b ) {
		if ( a > b ) {
				return a;
		} else {
				return b;
		}
}
int minimo ( int a, int b ) {
		if ( a < b ) {
				return a;
		} else {
				return b;
		}
}
