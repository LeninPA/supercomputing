int suma(int , int);
int maximo(int , int);
int minimo(int , int);
float promedio(int[]);
