# Tarea 1 - Curso de Programación en C
## Lenin Pavón Alvarez
- Instrucciones de compilación
	- Todos los programas tienen la nomenclatura t1-pX.c donde X es el número de programa. 
	- Para ejecutarlos se necesita primero compilarlos para lo que usamos el comando `gcc -o t1-pX t1-pX.c` lo cual hace que se compile el archivo t1-pX.c y su salida se vaya al ejecutable `t1.pX`
