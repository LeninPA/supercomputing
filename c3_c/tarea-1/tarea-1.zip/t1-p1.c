#include <stdio.h>

int main(void) {
	printf("Nombre: Lenin Pavón Alvarez\n");
	printf("Fecha de nacimiento: 2003-11-19\n");
	printf("Correo de contacto: lenin.pavon@comunidad.unam.mx\n");
	return 0;
}
